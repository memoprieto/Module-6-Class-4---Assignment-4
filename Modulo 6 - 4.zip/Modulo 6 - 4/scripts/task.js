class Task{
    constructor(id, title, important, duration, deadline, location, status) {
        this.id=id;
        this.title=title;
        this.important=important;
        this.duration=duration;
        this.deadline=deadline;
        this.location=location;
        this.status=status;

        this.name="Sergio";
    }
}